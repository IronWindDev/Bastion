#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

import bashbot.main

#  ____            _     ____        _
# | __ )  __ _ ___| |__ | __ )  ___ | |_
# |  _ \ / _` / __| '_ \|  _ \ / _ \| __|
# | |_) | (_| \__ \ | | | |_) | (_) | |_
# |____/ \__,_|___/_| |_|____/ \___/ \__|
#
# █ Bot for Discord █ Author: Adikso █

if __name__ == '__main__':
    sys.exit(bashbot.main.main(installed=False))
